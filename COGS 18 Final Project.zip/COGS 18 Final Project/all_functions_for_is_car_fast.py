import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import display, Markdown


data = np.array([[15.5, 12],
                 [14.5, 13],
                 [16, 13.5],
                 [14.2, 13.1],
                 [14.1, 12.9]])

df = pd.DataFrame(data, columns=['Time (seconds)', 'Speed (m/s)'])
df.index = ['Trial one', 'Trial two', 'Trial three', 'Trial four', 'Trial five']


def find_your_crank_hp(tq, rpm):
    '''
    Uses torque to find crank or engine horsepower 
    
    Parameters
    ----------
    torque : integer 
        The total torque produced by an engine. A whole number not a float 
        
    Returns
    -------
    crank horsepower : integer 
        The crank horsepower of the engine, rounded to a whole number
    '''
    
    
    crank_hp = tq * rpm/5252
    return round(crank_hp) 


def convert_crank_into_wheel(crank_hp, transmission, driveline):
    '''
    Takes the crank horsepower and the transmission type, as well as driveline, to calculate wheel horsepower
    
    Parameters
    ----------
    
    crank horsepower : integer 
        The integer retrieved from the function that calculates crank horsepower 
    transmission : string 
        The type of transmission the car is equipped with 
    driveline : string
        The status of the car as all wheel drive or not 
    
    Returns
    -------
    Wheel horsepower : integer
        Wheel horsepower rounded to the nearest whole number.
    '''
    
    
    if transmission == 'Automatic':
        parasitic_loss = .15
    elif transmission == 'Manual':
        parasitic_loss = .10
    elif transmission == 'DCT_Automatic':
        parasitic_loss = 0.13
    else:
        parasitic_loss = .15
    
    if 'all' in driveline.lower():
        driveline_loss = 0.05
    else:
        driveline_loss = 0 
    
    wheel_hp = crank_hp * (1.0 - parasitic_loss) * (1.0 - driveline_loss)
    
    return round (wheel_hp)


def is_my_car_fast(wheel_hp):
    '''
    Uses an input box and series of conditionals to see if a car is fast 
    
    Input
    -----
        User inputs a number for their wheel horsepower and the conditionals see what category it belongs in
        
    Returns
    -------
        None
    '''
    
    
    wheel_hp = int(wheel_hp)
    
    if wheel_hp < 275:
        print('Sorry, you do not have a fast car. :(')
    elif wheel_hp >= 275 and wheel_hp <= 500:
        print('Congrats! You have a fast car. :)')
    if wheel_hp >= 501 and wheel_hp <= 750:
        print('Wow! You have a really fast car.')
    if wheel_hp > 750:
        print('Remember they top out at 140.')


def you_need_car_info():
    '''
    Uses above functions to make a chatbot that ends with the is my car fast result 
    
    Input
    -----
        User inputs integers and strings as directed by the chatbot 
       
    Returns
    -------
        None
    '''
    print('You will need your engine torque, peak rpm, transmission type, and what wheels are driven.')
    torque = float(input('Please write your car\'s peak torque (can be found in the owner\'s manual): '))
    rpm = float(input('Please write your car\'s peak rpm (can be found in the owner\'s manual): '))
    transmission = input('Please write your car\'s transmission type (you should know this): ')
    drivetrain = input('Please write what wheels are driven in your car (e.g., front-wheel drive, rear-wheel drive, all-wheel drive): ')
    
    crank_hp = find_your_crank_hp(torque, rpm)
    wheel_hp = convert_crank_into_wheel(crank_hp, transmission, drivetrain)
    result = is_my_car_fast(wheel_hp)
    return result
    

def car_buying():
    '''
    Provides car buying advice based on user input.

    Inputs
    ------
        This function is a chat bot that is programed to ask the user if they want help buying a car.
        If the answer is yes, it will always reccomend a Lotus Exige, or end the chat. 

    Returns
    -------
        None
    '''
    
    print('Hi. I am a chatbot to help with buying a car')
    response = input('Do you want a car? yes or no? ')
    
    if response.lower() in ['yes', 'yeah', 'yea', 'Yes', 'Yeah', 'Yea']:
        print('You should look at a Lotus Exige, they have a modified Toyota Camry engine!')
    else:
        print('I dont want to talk to you anymore')


def convert_ms_into_kmh(speed_ms):
    '''
    Convert a speed from meters per second (m/s) to kilometers per hour (km/h).

    Parameters
    ----------
    speed_ms : float
        Speed value in meters per second (m/s).

    Returns
    -------
    speed kmh : float
        Speed value converted to kilometers per hour (km/h).
    '''
    
    speed_in_kmps = speed_ms / 1000
    speed_in_kmpm = speed_in_kmps * 60
    speed_in_kmph = speed_in_kmpm * 60
    
    return round(speed_in_kmph)


def fastest_trial(trials):
    '''
    Find the fastest trial based on the least amount of time.

    Parameters
    ----------
    trials : list
        List of tuples representing trial data. Each tuple should contain the time taken for a trial.

    Returns
    -------
    time : float
        The total time for the fastest trial measured in seconds
    ''' 
    
    
    fastest_run = None
    
    for trial in trials:
        time = trial[0] 
        if fastest_run is None or time < fastest_run:
            fastest_run = time
    
    return fastest_run


def rainbow_text(text):
    rainbow_text = ''
    rainbow_colors = ['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet']
    
    for index, letter in enumerate(text):
        color = rainbow_colors[index % len(rainbow_colors)]
        rainbow_text += f'<span style="color: {color};">{letter}</span>'
        
    display(Markdown(rainbow_text))


def convert_trials(trials, unit):
    '''
    Converts trial data from meters per second to kilometers per hour and determines the fastest trial based on the least time.

    Parameters
    ----------
    trials : list
        Tuples that contain the trial data. Each tuple should include the total time and the top speed.
    unit : str
        A measurement unit for speed, specifically meters per second (m/s).

    Prints
    ------
    String saying what the fastest trial was time wise and its top speed in seconds.

    Returns
    -------
    None
    '''
    
    fastest_trial = None
    fastest_time = float('inf')
    top_speed = 0 
    
    for trial, (time, speed) in enumerate(trials, start=1):
        converted_into_kmh = convert_ms_into_kmh(speed_ms)
        
        if time < fastest_time:
            fastest_trial = trial
            fastest_time = time
            top_speed = converted_into_kmh
            
    print(f'Your best trial was Trial {fastest_trial} which you completed in {fastest_time} seconds with a top speed of {top_speed} kmh. Good job!')
    

def plot_data(df):
    x = list(df.index)
    y = df['Speed (m/s)'].tolist()

    plt.figure(figsize=(14, 6))
    plt.plot(x, y, marker='o', linestyle='-')
    plt.xlabel('Attempts')
    plt.ylabel('Speed (m/s)')
    plt.title('Graph of Runs')

    for x_val, y_val in zip(x, y):
        plt.annotate(f'({x_val}, {y_val})', xy=(x_val, y_val), xytext=(10, -10), textcoords='offset points')
        
    plt.show()


def analyze_data(df):
    time_mean = np.mean(df['Time (seconds)'])
    time_std = np.std(df['Time (seconds)'])
    time_median = np.median(df['Time (seconds)'])
    time_min = np.min(df['Time (seconds)'])
    time_max = np.max(df['Time (seconds)'])
    time_range = time_max - time_min

    speed_mean = convert_ms_into_kmh(np.mean(df['Speed (m/s)']))
    speed_std = convert_ms_into_kmh(np.std(df['Speed (m/s)']))
    speed_median = convert_ms_into_kmh(np.median(df['Speed (m/s)']))
    speed_min = convert_ms_into_kmh(np.min(df['Speed (m/s)']))
    speed_max = convert_ms_into_kmh(np.max(df['Speed (m/s)']))
    speed_range = speed_max - speed_min

    print('Statistics for time:')
    print('Mean:', round(time_mean, 2), 'seconds')
    print('Standard deviation:', round(time_std, 2), 'seconds')
    print('Median:', round(time_median, 2), 'seconds')
    print('Minimum:', round(time_min, 2), 'seconds')
    print('Maximum:', round(time_max, 2), 'seconds')
    print('Range:', round(time_range, 2), 'seconds')

    print()
    print()

    print('Statistics for speed:')
    print('Mean:', round(speed_mean, 2), 'km/h')
    print('Standard deviation:', round(speed_std, 2), 'km/h')
    print('Median:', round(speed_median, 2), 'km/h')
    print('Minimum:', round(speed_min, 2), 'km/h')
    print('Maximum:', round(speed_max, 2), 'km/h')
    print('Range:', speed_range, 'km/h')

    print()
    print()


    text = f'The fastest overall time and speed were {round(time_min, 2)} seconds and {round(speed_max, 2)} km/h.'
    rainbow_text(text)